﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityCourseAndResultManagementWebApp.Models
{
    public class Designation
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}